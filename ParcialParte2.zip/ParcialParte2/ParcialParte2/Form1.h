#pragma once
#include "Interc.h"
namespace ParcialParte2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	Interc a;
	Interc b;
	Interc c;
	int pos=0, posi=0;


	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btnint;
	protected: 

	protected: 
	private: System::Windows::Forms::TextBox^  txtval2;
	private: System::Windows::Forms::TextBox^  txttam2;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Button^  btnval2;
	private: System::Windows::Forms::Button^  btndef2;
	private: System::Windows::Forms::Button^  btnin1;
	private: System::Windows::Forms::Button^  btndef1;
	private: System::Windows::Forms::DataGridView^  grid3;

	private: System::Windows::Forms::DataGridView^  grid2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridView^  grid1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::TextBox^  txtval1;
	private: System::Windows::Forms::TextBox^  txttam1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btnint = (gcnew System::Windows::Forms::Button());
			this->txtval2 = (gcnew System::Windows::Forms::TextBox());
			this->txttam2 = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->btnval2 = (gcnew System::Windows::Forms::Button());
			this->btndef2 = (gcnew System::Windows::Forms::Button());
			this->btnin1 = (gcnew System::Windows::Forms::Button());
			this->btndef1 = (gcnew System::Windows::Forms::Button());
			this->grid3 = (gcnew System::Windows::Forms::DataGridView());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->grid2 = (gcnew System::Windows::Forms::DataGridView());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->grid1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->txtval1 = (gcnew System::Windows::Forms::TextBox());
			this->txttam1 = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grid3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grid2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grid1))->BeginInit();
			this->SuspendLayout();
			// 
			// btnint
			// 
			this->btnint->Location = System::Drawing::Point(778, 51);
			this->btnint->Margin = System::Windows::Forms::Padding(4);
			this->btnint->Name = L"btnint";
			this->btnint->Size = System::Drawing::Size(100, 28);
			this->btnint->TabIndex = 31;
			this->btnint->Text = L"Intercalar";
			this->btnint->UseVisualStyleBackColor = true;
			this->btnint->Click += gcnew System::EventHandler(this, &Form1::btnint_Click);
			// 
			// txtval2
			// 
			this->txtval2->Location = System::Drawing::Point(432, 75);
			this->txtval2->Margin = System::Windows::Forms::Padding(4);
			this->txtval2->Name = L"txtval2";
			this->txtval2->Size = System::Drawing::Size(75, 22);
			this->txtval2->TabIndex = 30;
			// 
			// txttam2
			// 
			this->txttam2->Location = System::Drawing::Point(432, 28);
			this->txttam2->Margin = System::Windows::Forms::Padding(4);
			this->txttam2->Name = L"txttam2";
			this->txttam2->Size = System::Drawing::Size(75, 22);
			this->txttam2->TabIndex = 29;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(376, 75);
			this->label4->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(60, 17);
			this->label4->TabIndex = 28;
			this->label4->Text = L"Valores:";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(376, 28);
			this->label3->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(64, 17);
			this->label3->TabIndex = 27;
			this->label3->Text = L"Tama�o:";
			// 
			// btnval2
			// 
			this->btnval2->Location = System::Drawing::Point(517, 65);
			this->btnval2->Margin = System::Windows::Forms::Padding(4);
			this->btnval2->Name = L"btnval2";
			this->btnval2->Size = System::Drawing::Size(100, 28);
			this->btnval2->TabIndex = 26;
			this->btnval2->Text = L"Ingresar";
			this->btnval2->UseVisualStyleBackColor = true;
			this->btnval2->Click += gcnew System::EventHandler(this, &Form1::btnval2_Click);
			// 
			// btndef2
			// 
			this->btndef2->Location = System::Drawing::Point(517, 28);
			this->btndef2->Margin = System::Windows::Forms::Padding(4);
			this->btndef2->Name = L"btndef2";
			this->btndef2->Size = System::Drawing::Size(100, 28);
			this->btndef2->TabIndex = 25;
			this->btndef2->Text = L"Definir";
			this->btndef2->UseVisualStyleBackColor = true;
			this->btndef2->Click += gcnew System::EventHandler(this, &Form1::btndef2_Click);
			// 
			// btnin1
			// 
			this->btnin1->Location = System::Drawing::Point(195, 57);
			this->btnin1->Margin = System::Windows::Forms::Padding(4);
			this->btnin1->Name = L"btnin1";
			this->btnin1->Size = System::Drawing::Size(100, 28);
			this->btnin1->TabIndex = 24;
			this->btnin1->Text = L"Ingresar";
			this->btnin1->UseVisualStyleBackColor = true;
			this->btnin1->Click += gcnew System::EventHandler(this, &Form1::btnin1_Click);
			// 
			// btndef1
			// 
			this->btndef1->Location = System::Drawing::Point(195, 28);
			this->btndef1->Margin = System::Windows::Forms::Padding(4);
			this->btndef1->Name = L"btndef1";
			this->btndef1->Size = System::Drawing::Size(100, 28);
			this->btndef1->TabIndex = 23;
			this->btndef1->Text = L"Definir";
			this->btndef1->UseVisualStyleBackColor = true;
			this->btndef1->Click += gcnew System::EventHandler(this, &Form1::btndef1_Click);
			// 
			// grid3
			// 
			this->grid3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grid3->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column3});
			this->grid3->Location = System::Drawing::Point(700, 148);
			this->grid3->Margin = System::Windows::Forms::Padding(4);
			this->grid3->Name = L"grid3";
			this->grid3->Size = System::Drawing::Size(215, 185);
			this->grid3->TabIndex = 22;
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"Intercalado";
			this->Column3->Name = L"Column3";
			// 
			// grid2
			// 
			this->grid2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grid2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column2});
			this->grid2->Location = System::Drawing::Point(376, 148);
			this->grid2->Margin = System::Windows::Forms::Padding(4);
			this->grid2->Name = L"grid2";
			this->grid2->Size = System::Drawing::Size(241, 185);
			this->grid2->TabIndex = 21;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Valores";
			this->Column2->Name = L"Column2";
			// 
			// grid1
			// 
			this->grid1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grid1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->grid1->Location = System::Drawing::Point(82, 148);
			this->grid1->Margin = System::Windows::Forms::Padding(4);
			this->grid1->Name = L"grid1";
			this->grid1->Size = System::Drawing::Size(232, 185);
			this->grid1->TabIndex = 20;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Valores";
			this->Column1->Name = L"Column1";
			// 
			// txtval1
			// 
			this->txtval1->Location = System::Drawing::Point(102, 71);
			this->txtval1->Margin = System::Windows::Forms::Padding(4);
			this->txtval1->Name = L"txtval1";
			this->txtval1->Size = System::Drawing::Size(69, 22);
			this->txtval1->TabIndex = 19;
			// 
			// txttam1
			// 
			this->txttam1->Location = System::Drawing::Point(102, 31);
			this->txttam1->Margin = System::Windows::Forms::Padding(4);
			this->txttam1->Name = L"txttam1";
			this->txttam1->Size = System::Drawing::Size(69, 22);
			this->txttam1->TabIndex = 18;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(21, 71);
			this->label2->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(60, 17);
			this->label2->TabIndex = 17;
			this->label2->Text = L"Valores:";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(17, 31);
			this->label1->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(64, 17);
			this->label1->TabIndex = 16;
			this->label1->Text = L"Tama�o:";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1070, 374);
			this->Controls->Add(this->btnint);
			this->Controls->Add(this->txtval2);
			this->Controls->Add(this->txttam2);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->btnval2);
			this->Controls->Add(this->btndef2);
			this->Controls->Add(this->btnin1);
			this->Controls->Add(this->btndef1);
			this->Controls->Add(this->grid3);
			this->Controls->Add(this->grid2);
			this->Controls->Add(this->grid1);
			this->Controls->Add(this->txtval1);
			this->Controls->Add(this->txttam1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grid3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grid2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grid1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btndef1_Click(System::Object^  sender, System::EventArgs^  e) {
				 int tam;
				 tam=System::Convert::ToInt32(txttam1->Text);
				 a.set_tam(tam);
				 grid1->RowCount=tam;
			 }
private: System::Void btnin1_Click(System::Object^  sender, System::EventArgs^  e) {
			 int num;
			 num=System::Convert::ToInt32(txtval1->Text);
			 a.set_vec(pos,num);
			 grid1->Rows[pos]->Cells[0]->Value=num;
			 pos++;
		 }
private: System::Void btndef2_Click(System::Object^  sender, System::EventArgs^  e) {
			 int tam;
				 tam=System::Convert::ToInt32(txttam2->Text);
				 b.set_tam(tam);
				 grid2->RowCount=tam;

		 }
private: System::Void btnval2_Click(System::Object^  sender, System::EventArgs^  e) {
			 int num;
			 num=System::Convert::ToInt32(txtval2->Text);
			 b.set_vec(posi,num);
			 grid2->Rows[posi]->Cells[0]->Value=num;
			 posi++;

		 }
private: System::Void btnint_Click(System::Object^  sender, System::EventArgs^  e) {
			 c=c.Intercalar(a,b);
			 grid3->RowCount=c.get_tam();
			 for(int i=0; i<c.get_tam(); i++)
			 {grid3->Rows[i]->Cells[0]->Value=c.get_vec(i);}
		 }
};
}

