#pragma once
#define N 40

class Interc

{
private:
	int vec[N];
	int tamano;


public:
	Interc(void);
	int get_vec(int pos);
	void set_vec(int pos, int g);
		int get_tam();
	void set_tam(int tam);
	Interc Intercalar(Interc x, Interc y);

};

